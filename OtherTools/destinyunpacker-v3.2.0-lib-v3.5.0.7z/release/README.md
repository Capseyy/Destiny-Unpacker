Destiny Ada Unpacker
======================

This is a high-performance multithreaded unpacker for Destiny 1 and 2, written in Ada.  

>	Note: To comply with legal requirements, only use this program for personal,
>	educative purposes and to bolster interoperability of Destiny (2) with other
>	programs. Do not publish the contents of any Destiny package files without
>	Bungie's explicit permission.

Setup and Usage
---------------

If you would like to build from source, see `BUILDING.md`. Otherwise,
download a release from the Releases section.

Destiny 1 and 2 packages are compressed with a library called Oodle, which is
distributed under an All Rights Reserved license and thus cannot be included.

**Please note:**  

Oodle libraries are _not_ required if you are only interested in extracting WEM music
files or USM cutscenes. "Dummy" versions of these libraries are included that do not work,
but will allow program operation.  

If you do need to extract other file types, however, follow these steps:  

	- If you intend to use Destiny 1 or Destiny 2 before Beyond Light,
	acquire oo2core_3_win64.dll from the Destiny 2 Shadowkeep game install
	directory and place it in the same directory as the tool.

	- (On Linux) If you intend to use Destiny 2 after Beyond Light,
	acquire oo2corelinux64.so.9 and replace the dummy file in ext_lib with it.
	You can find this file in the Unreal Engine 4/5 Source Code Repository.
	See the warning in the Reference
	section to understand the legal implications of using these files.  

	- (On Windows) If you intend to use Destiny 2 after Beyond Light,
	acquire oo2core_9_win64.dll and place it in the same directory as the tool. You can
	get this file from the Destiny 2 Witch Queen game install.  

Run the program with no arguments to see the available options and syntax.

If any errors occur during unpacking, please add them to an Issue so I can investigate.  

Reference
---------

>	RAD Game Tools, Epic Game Tools, etc. reserve the right to define the terms under which users may
>	use Oodle and related software, to which they own the copyright.
>	If unsure, you might consider purchasing a license to Oodle 2.9.

>	Even though this program is licensed under the GPL, its linking with Oodle makes the actual license unclear.
>	I optionally make this program available under the terms of the LGPL v3 for anyone whom that would assist.

Currently supported versions of the game are d1be (Destiny 1 Big Endian / PS3), d1 (Destiny 1 Little Endian / PS4),
prebl (Destiny 2 before Beyond Light), and postbl (Destiny 2 after Beyond Light).  

Currently-available optional file formats are String\_Reference, Audio\_Reference, Metadata\_Sound, Metadata\_Music, BNK (WWise Audio Bank), WEM (WWise Encoded Media), USM (ScaleForm Video), DDS\_2D, DDS\_3D, and Unknown (everything else).  
Choosing to extract Unknown files results in approximately 80GiB of output, in addition to any other selected options.

Currently-available String languages are: English, Japanese, German, French, Spanish\_LA, Spanish\_ES, Italian, Portuguese, Polish, Russian, Korean, Chinese\_Traditional, and Chinese\_Simplified  
Please note that Russian is not available in Destiny 1, and that Chinese (both variants), Spanish\_ES, and Korean are region-locked in Destiny 1.  

Processors are a feature that allows the Unpacker to transform raw game data into a more human-readable format. If you are developing tools to interact with the raw data, you can disable them (see the usage screen for more information).  

If you disable processors, the following additional formats become available: DDS\_Body, String\_Bank.  

To extract audio as WAV, consider using the tool "destiny-batch-audio-unpacker". Builds for this are available in the Releases section.  
To convert BNK files to a textual representation, please try WWiser or https://github.com/andrewathalye/wwtools-ada.   
VGMStream can play the resulting TXTP files, without requiring conversion of WEM audio to WAV format.  

Credit
------

Thank you to nblockbuster and MontagueM, without whose work on DestinyUnpackerCPP this
project would never have been possible.

https://www.github.com/nblockbuster/DestinyUnpackerCPP and
https://www.github.com/MontagueM/DestinyUnpackerCPP

Additionally, I give my thanks to McSimp and https://github.com/McSimp/linoodle, without which
I would have been unable to decompress most pre-Beyond Light packages on Linux.
