/* libunpacker
 * C99 interface header
 *
 * Licensed under the terms of the GNU General Public License, Version 3
 * In any event where this header file and the Ada specfication of libunpacker are not consistent,
 * the latter shall be held enforceable.
 *
 * */
#ifndef DESTINY_UNPACKER_H
#define DESTINY_UNPACKER_H

#if defined (__cplusplus)
extern "C" {
#endif

#include <stdint.h>

/* From Unpacker */
typedef struct unpacker_pkgctx unpacker_pkgctx_t;
enum unpacker_mode {UNPACKER_D1BE, UNPACKER_D1, UNPACKER_PREBL, UNPACKER_POSTBL};

/* From Unpacker.Interfaces.C */
enum unpacker_result {
	UNPACKER_NAME_ERROR = -6,
	UNPACKER_PACKAGE_CACHE_EXCEPTION = -5,
	UNPACKER_EXTRACT_EXCEPTION = -4,
	UNPACKER_ENTRY_NOT_FOUND = -3,
	UNPACKER_INVALID_PACKAGE_CONTEXT = -2,
	UNPACKER_PACKAGE_EXCEPTION = -1,
	UNPACKER_FALSE = 0,
	UNPACKER_TRUE = 1};

/* From Unpacker.Interfaces */
const extern uint32_t UNPACKER_VERSION;

/* From Unpacker_Package_File */
struct unpacker_header {
	uint16_t pkgid;
	uint32_t buildid;
	uint16_t patchid;
	uint32_t entry_table_size;
	uint32_t reserved1; /* entry_table_offset */
	uint32_t reserved2; /* block_table_size */
	uint32_t reserved3; /* block_table_offset */
};

struct unpacker_entry {
	uint32_t reference;
	uint8_t type;
	uint8_t subtype;
	uint32_t reserved1; /* starting_block */
	uint32_t reserved2; /* starting_block_offset */
	uint32_t reserved3; /* last_block */
	uint32_t file_size;
};

/* From Unpacker.Package_File.Types */
enum unpacker_entry_info {
	UNPACKER_UNKNOWN,
	UNPACKER_STRING_BANK,
	UNPACKER_STRING_REFERENCE,
	UNPACKER_STRING_REFERENCE_INDEX,
	UNPACKER_FONT_REFERENCE,
	UNPACKER_LOADZONE,
	UNPACKER_MAIN_MODEL,
	UNPACKER_SUBFILES,
	UNPACKER_DYNAMIC_HEADER,
	UNPACKER_ANIMATION,
	UNPACKER_TERRAIN,
	UNPACKER_MATERIAL,
	UNPACKER_AUDIO_REFERENCE,
	UNPACKER_METADATA_SOUND,
	UNPACKER_METADATA_MUSIC,
	UNPACKER_JUNK,
	UNPACKER_BNK,
	UNPACKER_INDEX_BUFFER,
	UNPACKER_WEM,
	UNPACKER_HAVOK,
	UNPACKER_VIDEO_UNKNOWN,
	UNPACKER_USM,
	UNPACKER_TEXT_REFERENCE,
	UNPACKER_DDS_2D,
	UNPACKER_DDS_3D,
	UNPACKER_VERTEX_BUFFER
};

/* All functions return a negative enum unpacker_result on failure and a natural enum unpacker_result on success */

/* From Unpacker.Package_File */
unpacker_pkgctx_t * unpacker_open (enum unpacker_mode, const char * filename);
unpacker_pkgctx_t * unpacker_open_id (enum unpacker_mode, const char * dirname, uint16_t pkgid);

/* Note: Closing a package context will set the pointer's value to NULL */
enum unpacker_result unpacker_close (unpacker_pkgctx_t **);

enum unpacker_result unpacker_find_entry (unpacker_pkgctx_t *, uint16_t index, struct unpacker_entry *);

/* Pre-allocate space (unpacker_header.entry_table_size * sizeof (struct unpacker_entry)) */
enum unpacker_result unpacker_dump_entries (unpacker_pkgctx_t *, struct unpacker_entry * entries);

enum unpacker_result unpacker_dump_header (unpacker_pkgctx_t *, struct unpacker_header *);
enum unpacker_result unpacker_dump_mode (unpacker_pkgctx_t *, enum unpacker_mode *);

/* From Unpacker.Package_File.Extract */
/* Sufficient space must be allocated beforehand (usually unpacker_entry.file_size) */
enum unpacker_result unpacker_extract (unpacker_pkgctx_t *, const struct unpacker_entry *, void * data);
enum unpacker_result unpacker_extract_uncacheable (unpacker_pkgctx_t *, const struct unpacker_entry *, void * data);

/* From Unpacker.Package_File.Types */
enum unpacker_result unpacker_get_info (unpacker_pkgctx_t *, const struct unpacker_entry *, enum unpacker_entry_info *);

/* From Unpacker_Util */
enum unpacker_result unpacker_is_latest_patchid (const char * pkgname);
uint16_t unpacker_to_pkgid (uint32_t hash);
uint16_t unpacker_to_entryid (uint32_t hash);
uint32_t unpacker_to_hash (uint16_t pkgid, uint16_t entryid);

#if defined (__cplusplus)
}
#endif
#endif
